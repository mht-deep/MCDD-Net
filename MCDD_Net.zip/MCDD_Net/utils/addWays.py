import numpy as np
import torch
import torch.nn as nn
import pywt
import math
import torch.nn.functional as F

class MSCA(nn.Module):
    """专门针对肠息肉分割的边界增强模块"""

    def __init__(self, in_channels, edge_threshold=0.1):
        """
        参数：
            in_channels: 输入通道数
            edge_threshold: 边缘阈值，过滤弱边缘
        """
        super().__init__()
        self.edge_threshold = edge_threshold

        # 改进的边缘检测
        self.edge_detector = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1, groups=in_channels),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )

        # 多尺度边缘检测
        self.avg_pool1 = nn.AvgPool2d(3, 1, 1)
        self.avg_pool2 = nn.AvgPool2d(5, 1, 2)

        # 边界注意力生成
        self.boundary_attention = nn.Sequential(
            nn.Conv2d(in_channels * 2, in_channels // 4, kernel_size=1),
            nn.BatchNorm2d(in_channels // 4),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels // 4, in_channels, kernel_size=1),
            nn.Sigmoid()
        )

        # 过渡区增强（专门针对息肉边界模糊问题）
        self.transition_enhancer = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1),
            nn.GroupNorm(8, in_channels),  # 用GroupNorm代替BatchNorm，对batch size不敏感
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        B, C, H, W = x.shape

        # 1. 多尺度边缘检测
        edge1 = torch.abs(x - self.avg_pool1(x))  # 细边缘
        edge2 = torch.abs(x - self.avg_pool2(x))  # 粗边缘

        # 2. 结合多尺度边缘
        multi_scale_edge = torch.cat([edge1, edge2], dim=1)

        # 3. 生成边界注意力图
        boundary_attention = self.boundary_attention(multi_scale_edge)

        # 4. 应用阈值，增强强边界
        strong_boundary_mask = (boundary_attention > self.edge_threshold).float()
        boundary_attention = boundary_attention * strong_boundary_mask

        # 5. 增强边界区域特征
        boundary_features = x * (1 + boundary_attention)

        # 6. 专门处理过渡区
        transition_features = self.transition_enhancer(boundary_features)

        # 7. 残差连接
        output = x + 0.3 * transition_features  # 控制增强强度

        return output

def create_gaussian_filter(h, w, sigma=1.0):
    center_h, center_w = h // 2, w // 2
    y, x = torch.meshgrid(torch.arange(h), torch.arange(w), indexing='ij')
    y = y - center_h
    x = x - center_w
    gauss = torch.exp(-(x**2 + y**2) / (2 * sigma**2))
    gauss = gauss / gauss.max()
    return gauss.unsqueeze(0).unsqueeze(0)

class DFEBlock(nn.Module):
    def __init__(self, inc, outc, sigma1=1.5, sigma2=3.0, eps=1e-5):
        super().__init__()
        self.sigma1 = sigma1
        self.sigma2 = sigma2
        self.eps = eps
        self.channel_adjust = nn.Conv2d(inc, outc, 1)
        self.gate = nn.Sequential(
            nn.Conv2d(outc * 2, outc, 1),
            nn.Sigmoid()
        )

    def frequency_attention(self, x):
        b, c, h, w = x.shape
        fft = torch.fft.fft2(x, dim=(-2, -1))
        fft_shift = torch.fft.fftshift(fft)

        g1 = create_gaussian_filter(h, w, self.sigma1).to(x.device)
        g2 = create_gaussian_filter(h, w, self.sigma2).to(x.device)
        bilateral = g1 * g2
        plain = create_gaussian_filter(h, w, (self.sigma1+self.sigma2)/2).to(x.device)

        fft1 = fft_shift * bilateral
        fft2 = fft_shift * plain
        diff = torch.abs(fft1 - fft2)

        ifft_shift = torch.fft.ifftshift(diff)
        ifft = torch.fft.ifft2(ifft_shift, dim=(-2, -1))
        att = torch.abs(ifft)
        att = (att - att.min()) / (att.max() - att.min() + self.eps)
        return att

    def forward(self, x_lower, x_upper):
        x_lower = self.channel_adjust(x_lower)
        att = self.frequency_attention(x_lower)
        enhanced = x_upper * att
        concat = torch.cat([x_upper, enhanced], dim=1)
        weight = self.gate(concat)
        out = weight * enhanced + (1 - weight) * x_upper
        return out

class MultiScaleFusion(nn.Module):
    def __init__(self, channels,out):
        super().__init__()
        # 双分支3×3卷积 + Concat
        self.branch1 = nn.Conv2d(channels, out, kernel_size=3, padding=1)
        self.branch2 = nn.Conv2d(out, out, kernel_size=3, padding=1)
    def forward(self, x):

        x1 = self.branch1(x)
        x2 = self.branch2(x1)
        return x2

class MultiScaleFusion1(nn.Module):
    def __init__(self, channels):
        super().__init__()
        # 双分支3×3卷积 + Concat
        self.branch1 = nn.Conv2d(channels * 2, channels, kernel_size=3, padding=1)
        self.branch2 = nn.Conv2d(channels, channels, kernel_size=3, padding=1)
    def forward(self, x):
        x1 = self.branch1(x)
        x2 = self.branch2(x1)
        return x2